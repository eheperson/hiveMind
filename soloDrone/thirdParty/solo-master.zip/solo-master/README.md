# solo
Dronekit Python with 3DR Solo
