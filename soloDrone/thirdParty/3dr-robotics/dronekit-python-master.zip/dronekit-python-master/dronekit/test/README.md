# dronekit-python tests

Before running, make sure to export your api keys:

```
export DRONEAPI_KEY=<app id>.<app key>
```

Run tests using nose (`pip install nose`):

```
$ nosetests
..............
----------------------------------------------------------------------
Ran _ tests in _.___s

OK
```
