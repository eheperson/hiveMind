#!/bin/bash

ssh dronekit.io "./update_python.sh"
