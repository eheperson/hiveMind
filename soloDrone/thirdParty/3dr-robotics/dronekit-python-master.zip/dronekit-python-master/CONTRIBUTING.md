# Contributing to DroneKit Python

Please see [the Contribution Guide](http://python.dronekit.io/contributing/) on dronekit.io for details.
