#pragma once

#define HIGH 1
#define LOW 0
