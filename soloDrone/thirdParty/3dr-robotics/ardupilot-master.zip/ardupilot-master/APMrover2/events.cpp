// -*- tab-width: 4; Mode: C++; c-basic-offset: 4; indent-tabs-mode: nil -*-

#include "Rover.h"

void Rover::update_events(void)
{
    ServoRelayEvents.update_events();
}
