import logging
import sys


logging.basicConfig(level=logging.INFO, stream=sys.stdout)