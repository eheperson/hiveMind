#include "sys.h"

const uint8_t* const Sys::UniqueId = reinterpret_cast<uint8_t*>(0x1FFFF7E8);
