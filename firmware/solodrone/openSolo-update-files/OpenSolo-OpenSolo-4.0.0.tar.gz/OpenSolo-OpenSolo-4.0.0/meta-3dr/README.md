WARNING - WORK IN PROGRESS

```
This code is known to be high risk , but also early-adopter friendly.  


We will remove this warning from the repository when it is no longer required.
```


# meta-3dr

This project contains the build definition of the whole i.MX6 Yocto image. 

The image is built using Yocto's [BitBake](https://www.yoctoproject.org/tools-resources/projects/bitbake) build engine. The build definition consists of a large set of "Bitbake recipes" for the different included software (including ShotManager, SoloLink, and numerous other tools).  

This readme does not attempt to fully describe the project as this requires an in-depth knowledge of Bitbake. 
A good place to get started is the [Bitbake User Manual](http://www.yoctoproject.org/docs/2.0/bitbake-user-manual/bitbake-user-manual.html).

**Note:** This release is published as a starting point for opening the Solo codebase. Many of the URLs in the recipes will have to be updated to point at the newly-opened code.
