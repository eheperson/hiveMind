# enum matches C++ implementation 

MsgID = [
        'Nop',                \
        'DsmChannels',        \
        'Calibrate',          \
        'SysInfo',            \
        'Mavlink',            \
        'SetRawIo',           \
        'RawIoReport',        \
        'PairRequest',        \
        'PairConfirm',        \
        'PairResult',         \
        'ShutdownRequest',    \
        'ParamStoredVals',    \
        'OutputTest',         \
        'ButtonEvent',        \
        'InputReport',        \
        'ConfigStickAxes',    \
        'ButtonFunctionCfg',  \
        'SetShotInfo',        \
        'Updater',            \
        'LockoutState',       \
        'SelfTest',           \
        'ConfigSweepTime',    \
        'GpioTest',           \
        'TestEvent',          \
        'SetTelemUnits',      \
        'InvalidStickInputs', \
        'SoloAppConnection',  \
        ]
