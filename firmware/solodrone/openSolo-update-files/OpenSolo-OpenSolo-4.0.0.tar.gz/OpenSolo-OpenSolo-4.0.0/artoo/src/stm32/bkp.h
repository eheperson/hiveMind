#ifndef BKP_H
#define BKP_H

#include "hw.h"
#include "common.h"

class Bkp
{
public:
    Bkp();  // do not implement

    static void init();
    static void reset();
};

#endif // BKP_H
