#!/bin/sh

# fire up a GDB session

arm-none-eabi-gdb -q artoo.elf
