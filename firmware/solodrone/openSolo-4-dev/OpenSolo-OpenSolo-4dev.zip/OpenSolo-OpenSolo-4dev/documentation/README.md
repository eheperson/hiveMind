# Open Solo Releases For Users #

[Go to the Open Solo github Wiki for Open Solo documentation and instructions](https://github.com/Pedals2Paddles/OpenSolo/wiki)
